% pr21_2.m
% multihaar
% Multi Resolution Analysis MRA Haar Wavelet Analysis

close all;clear;clc;

N=1024;                                 % # of points

for n=1:N;m=(n-1)/N;g(n)=20*m^2*(1-m)^4*cos(12*pi*m);end; % input signal 

for m=1:N/2;
    a1(m)=(g(2*m-1)+g(2*m))/sqrt(2);    % Use direct formulas for t and f 
    d1(m)=(g(2*m-1)-g(2*m))/sqrt(2);
end;

H1=[a1 d1];                             % The level-1 Haar transform

for m=1:N/4;
    a2(m)=(a1(2*m-1)+a1(2*m))/sqrt(2);  % Use direct formulas for t and f 
    d2(m)=(a1(2*m-1)-a1(2*m))/sqrt(2);
end;

H2=[a2 d2 d1];

for m=1:N/8;
    a3(m)=(a2(2*m-1)+a2(2*m))/sqrt(2);  % Use direct formulas for t and f 
    d3(m)=(a2(2*m-1)-a2(2*m))/sqrt(2);
end;

H3=[a3 d3 d2 d1];

figure
plot(H3,'k');
title(' MRA: H3 [a3 d1 d2 d3] ');

% Plot a few examples;
figure
plot(g,'r.'); hold; plot(g,'r');
axis tight
xlabel ('Time (Sample#)')
ylabel ('Amplitude')
title(' MRA: Original Signal 1024 samples (red) ')
figure
plot(d1,'.'); hold; plot(d1);
axis tight
xlabel ('Time (Sample#)')
ylabel ('Amplitude')
title('Fluctuation d1')
figure
plot(d2,'k.'); hold; plot(d2)
axis tight
xlabel ('Time (Sample#)')
ylabel ('Amplitude')
title('Trend d2')
figure
plot(d3,'.'); hold; plot(d3)
axis tight
xlabel ('Time (Sample#)')
ylabel ('Amplitude')
title('Fluctuation d3')
figure
plot(a3,'k.'); hold; plot(a3)
axis tight
xlabel ('Time (Sample#)')
ylabel ('Amplitude')
title('trend a3')


